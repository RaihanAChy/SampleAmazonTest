package tests;

import java.io.IOException;

import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;
import pageObjects.landingPage;
import resources.Base;

public class searchProductTest extends Base {

	private String browser = "chrome";
	private String url = "http://amazon.com";
	private String product = "Mobile Phones";

	@BeforeTest()
	public void initialize() throws IOException {
		driver = initilizeDriver(browser);
		driver.get(url);
	}

	@Test(priority = 1, description = "Search For A Product, Click Search Icon")

	public void searchForProductTest() {
		landingPage l = new landingPage(driver);
		l.searchProduct(product);
		l.clickSearchIcon();
	}

	@Test(priority = 2, description = "Click Prime CheckBox, Verify Prime Is Checked")

	public void clickPrimeAndVerifyTest() {

		landingPage l = new landingPage(driver);
		l.clickPrimeCheckBox();
		l.verifyPrimeSelected();
	}

	@Test(priority = 3, description = "Verify Search Result Header - Contains Product Searched")

	public void verifySearchResult() {
		landingPage l = new landingPage(driver);
		l.verifySearchResultHeader(product);
	}

	@AfterTest()

	public void tearDown() {
		driver.close();

	}

}
