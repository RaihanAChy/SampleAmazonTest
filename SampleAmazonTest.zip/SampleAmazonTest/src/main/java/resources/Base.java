package resources;

import java.io.IOException;
import java.util.concurrent.TimeUnit;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;

public class Base {

	public WebDriver driver;

	public WebDriver initilizeDriver(String browser) throws IOException {
		// chrome
		if (browser.equalsIgnoreCase("chrome")) {

			System.setProperty("webdriver.chrome.driver", "C://Software//driver//chromedriver.exe");
			driver = new ChromeDriver();

			// firefox
		} else if (browser.equalsIgnoreCase("firefox")) {
			driver = new FirefoxDriver();
			// System.setProperty("webdriver.gecko.driver", driverpath+geckodriver.exe);

		} else if (browser.equalsIgnoreCase("Internet Explorer")) {

			// IE
			driver = new InternetExplorerDriver();
			// System.setProperty("webdriver.ie.driver", driverpath+iedriver.exe);
		}

		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		return driver;
	}

}
