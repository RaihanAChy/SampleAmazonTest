package pageObjects;

import static org.testng.Assert.assertEquals;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import junit.framework.Assert;

public class landingPage {
	
	public WebDriver driver;
	
    
	//****************Elements***********************************
	
	@FindBy(xpath="//input[@id='twotabsearchtextbox']")
	private WebElement searchBox;
	
	@FindBy(xpath="//input[@value='Go']")
	private WebElement searchIcon;
	
	@FindBy(xpath="//div[@id='primeRefinements']//i")
	private WebElement primeCheckbox;
	
	@FindBy(xpath="//div[@id='primeRefinements']//input")
	private WebElement primeCheckboxSelected;
	
	@FindBy(xpath="//div[@class='sg-col-inner']/div/span[4]")
	private WebElement searchResultHeader;
	
	
	
//**************Constructor******************************************
	
	public landingPage(WebDriver driver) {
		// TODO Auto-generated constructor stub
		this.driver=driver;
		PageFactory.initElements(driver, this);
	}

	
	
	
	
//*************Methods***************************************
	
	
	// Searches for a product in amazon
	
    public void searchProduct( String product) {
    	searchBox.sendKeys(product);
    }
    
    
    
    //Clicks on the search icon
    
    public void clickSearchIcon() {
    	searchIcon.click();
    	
    }
    
    
    // clicks on the Prime Checkbox
    
    public void clickPrimeCheckBox() {
    	
    	primeCheckbox.click();
    }
    
    
    //validates - the prime checkbox is selected or not
    
    public void verifyPrimeSelected() {
    	if (primeCheckboxSelected.isSelected()) {
    		System.out.println("Prime Is Selected :" +primeCheckboxSelected.isSelected());
    	}else {
    		System.out.println("Prime Is Not Selected");
    		
    	}
    	 Assert.assertTrue(primeCheckboxSelected.isSelected());
    }
    
    
   //validates that the search result header shows product searched
    
    public void verifySearchResultHeader(String product) {
    	String HeaderText = searchResultHeader.getText();
    	if(HeaderText.contains(product)) {
    		System.out.println("Search Result Shows : " +product+" | "+ HeaderText.contains(product));
    	
    	}else {
    		System.out.println("Search Result Is Wrong");
    }
    	Assert.assertTrue(HeaderText.contains(product));
}
}

